#pragma once
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
using namespace std;

vector<string> fileReader(string path) {
    vector<string> text;
    fstream txt;
    txt.open(path);
    if (txt.is_open()) {
        string line;
        while (getline(txt, line)) {

            text.push_back(line);
        }
    }
    else {
        cout << "Error! Can't open the current file (" << path << ").\n";
    }
    txt.close();
    return text;
}