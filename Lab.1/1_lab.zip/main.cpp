#include "func.h"
int main() {
    go_func();
    return 0;
}