#pragma once
#include <cstdio>
#include <cstdlib>
#include "basic+lib.h"
#include "text_file+lib.h"
#include <fstream>
#include <map>

using namespace std;

void go_func() {
    vector<string> text = fileReader("data.txt");
    vector<string> data;
    vector<string> code; // code block
    vector<string> ans; // answer
    //vout(text, "\n");

    // начинаем искать блок данных
    string data_s = ".data";
    auto iter = text.begin();
    while(iter!=text.end() && ((*iter).substr(0,5)!=data_s)) {
        //fout(*iter, iter->size(), "\n");
        ++iter;
    }
    if(iter!=text.end()) {++iter;}

    // начинаем искать блок кода
    string code_s = ".code";
    while(iter!=text.end() && ((*iter).substr(0,5)!=code_s)) {
        data.push_back(*iter);
        ++iter;
        //fout("+");
    }
    if(iter!=text.end()) {++iter;}

    // начинаем собирать код
    while(iter!=text.end()) {
        code.push_back(*iter);
        ++iter;
        //fout("-");
    }
    //vout(data, "\n");
    //space(2);
    //vout(code, "\n");

    // читаем блок данных
    map<string, int> data_map;
    data_map.insert(make_pair("Ak", 0));
    for(auto line : data) {
        string name;
        int value = 0;
        bool minus = false;
        bool first = true;
        for(char n : line) {
            if( !((int)n<33 && (int)n>0) ) { // символы с кодом от 1 до 32 не учитываются
                if(n=='/') { break;}
                if(n=='-') { minus=true; continue;}
                if(first) {name += n;}
                // домножаем сразу value на 10*
                else {value += ((int)n - 48); value*=10;}
                if( (int)n==63 ) {
                    value=0;// если стоит знак ?, то мы знаем, что это результат, т.е. его значение изначально = 0
                    ans.push_back(name);
                }
            }
            else { first = false;}
        }
        // *убираем появившийся лишний десяток
        value/=10;
        // *добавляем знак минус (если нужен)
        if(minus) {value*=(-1);}
        data_map.insert(make_pair(name, value));
        //fout(name, " = ", value, "\n"); // для просмотра переменных
    }

    for(auto line : code) {
        //fout(data_map["x00"], "\n\n");
        string wtd; // (what to do) что делать с первым и вторым элементами
        string first;
        string second;
        bool wtd_is_f = false;// т.е. мы ещё не знаем, что делать
        bool first_is_f = false;
        for (char n : line) {
            if (!((int) n < 33 && (int) n > 0)) { // символы с кодом от 1 до 32 не учитываются
                if (n == '/') { break; }
                if (!wtd_is_f) {
                    wtd+=n;
                }
                else {
                    if (!first_is_f) {
                        first+=n;
                    }
                    else {second+=n;}
                }
            }
            else {
                if(wtd_is_f) {
                    first_is_f = true;
                }
                else {wtd_is_f = true;}
            }
        }
        if(wtd=="end") { break;}

        //        |1 |2 |3 |
        const int mov = 109111118;
        const int add =  97100100;
        const int mul = 109117108;

        //fout(data_map[second], " | ", data_map["x00"], "\n");
        //fout( (int)wtd[0], " ", (int)wtd[1], " ", (int)wtd[2], "\n");
        switch ( ( (int)wtd[0]*1000000 )+( (int)wtd[1]*1000 )+(int)wtd[2] ) {
            case(mov) :
                //fout(data_map[first], " = ", data_map[second]);
                data_map[first]=data_map[second];
                //fout(data_map[first], " ", data_map[ ans[0] ], "\n");
                break;
            case(add) :
                //fout(data_map[first], " = ", data_map[second]);
                data_map[first]+=data_map[second];
                //fout(data_map[first], " ", data_map[ ans[0] ], "\n");
                break;
            case(mul) :
                //fout(data_map[first], " and ", data_map[second], " ");
                data_map[first]*=data_map[second];
                //fout(data_map[first], " - ",data_map[second], " ", data_map[ ans[0] ], "\n");
                break;
            default:
                fout("Unnamed operation!");
        }
    }
    //fout(ans[0]);
    fout("Answer: ", data_map[ ans[0] ]);
}